$(document).ready(function() {
    $(".owl-carousel").owlCarousel({
        autoplay: true,
        autoplayhoverpause: true,
        autoplaytimeout: 100,
        //items: 4,
        nav: true,
        loop: true,
        margin: 50,
        padding: 5,
        stagePdding: 5,
    });
});
      