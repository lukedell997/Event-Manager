from flask import Flask, render_template

app = Flask(__name__)

admin = False

@app.route('/index')
@app.route('/')
@app.route('/index.html')
def index():  # put application's code here
    return render_template("index.html")

@app.route('/registerPage.html')
@app.route('/registerPage')
def registerPage():  # put application's code here
    return render_template("registerPage.html")

@app.route('/loginPage.html')
@app.route('/loginPage')
def loginPage():  # put application's code here
    return render_template("loginPage.html")

@app.route('/add_editEvents.html')
@app.route('/add_editEvents')
def add_editEvents():  # put application's code here
    return render_template("add_editEvents.html")

@app.route('/eventDetails.html')
@app.route('/eventDetails')
def eventDetails():  # put application's code here
    return render_template("eventDetails.html")

@app.route('/manageEvents.html')
@app.route('/manageEvents')
def manageEvents():  # put application's code here
    return render_template("manageEvents.html")

@app.route('/search_browseEvents.html')
@app.route('/search_browseEvents')
def search_browseEvents():  # put application's code here
    return render_template("search_browseEvents.html")

if __name__ == '__main__':
    app.run(debug=True)
