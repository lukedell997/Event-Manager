from flask import Flask, render_template, redirect, url_for, request, flash
from datetime import timedelta



app = Flask(__name__)
app.permanent_session_lifetime = timedelta(hours=5)

app.secret_key = "hello"

admin = False

@app.route('/index')
@app.route('/')
@app.route('/index.html')
def index():  # put application's code here
    return render_template("index.html")

@app.route('/registerPage.html')
@app.route('/registerPage')
def registerPage():  # put application's code here
    return render_template("registerPage.html")

@app.route('/loginPage.html', methods=["POST", "GET"])
@app.route('/loginPage', methods=["POST", "GET"])
def loginPage():  # put application's code here
    if request.method == "POST":
        session.permanent = True
        user = request.form["nm"]
        session["user:"] = user
        return redirect(url_for("user"))
    else:
        return render_template("loginPage.html")


#This is for when we have a user page
@app.route("/user")
def user(name=None):
    if "user" in session:
        user = session["user"]
        return f"<h1>{user}</h1>"
    else:
        if "user" in session:
            return redirect(url_for("user"))
        return redirect(url_for("login"), name = name)

# This is for a logout page
@app.route("/logout")
def logout():
    session.pop("user", None)
    #flash("You have been logged out!", "info")
    return  redirect(url_for("login"))


@app.route('/add_editEvents.html')
@app.route('/add_editEvents')
def add_editEvents():  # put application's code here
    return render_template("add_editEvents.html")

@app.route('/eventDetails.html')
@app.route('/eventDetails')
def eventDetails():  # put application's code here
    return render_template("eventDetails.html")

@app.route('/manageEvents.html')
@app.route('/manageEvents')
def manageEvents():  # put application's code here
    return render_template("manageEvents.html")

@app.route('/search_browseEvents.html')
@app.route('/search_browseEvents')
def search_browseEvents():  # put application's code here
    return render_template("search_browseEvents.html")

if __name__ == '__main__':
    app.run(debug=True)
